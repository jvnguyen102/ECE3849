/*
 * sampling.h
 *
 *  Created on: Nov 1, 2023, Modified 11/8/2023
 *      Author: Ben Bonen and Jacob Nguyen
 *
 *
 */

#ifndef SAMPLING_H_
#define SAMPLING_H_

#include <stdint.h>

#define ADC_SAMPLING_RATE 1000000   // [samples/sec] desired ADC sampling rate
#define CRYSTAL_FREQUENCY 25000000  // [Hz] crystal oscillator frequency used to calculate clock rates

#define PIXELS_PER_DIV 20
#define ADC_INT_PRIORITY 16  // button interrupt priority (higher number is lower priority)
#define VIN_RANGE 3.3
#define ADC_BITS 12
#define ADC_OFFSET 2048
#define ADC_BUFFER_SIZE 2048
#define ADC_BUFFER_WRAP(i) ((i) & (ADC_BUFFER_SIZE - 1))

extern volatile int32_t gADCBufferIndex;
extern volatile uint16_t gADCBuffer[]; // circular buffer
extern volatile uint32_t gADCErrors; // number of missed ADC deadlines
extern volatile bool triggerFound;

// initialize ADC1
void ADCInitialize(void);
void ADC_ISR(void);
int RisingTrigger(void);
int FallingTrigger(void);

#endif /* SAMPLING_H_ */
