/*
 * ECE 3849 Lab2 starter project
 *
 * Gene Bogdanov    9/13/2017
 */
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/cfg/global.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

#include <stdint.h>
#include <stdbool.h>
#include "driverlib/interrupt.h"

/* Lab 2 Header Files */
#include <sampling.h>
#include <buttons.h>
#include <stdint.h>
#include <stdbool.h>
#include "driverlib/fpu.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include <buttons.h>
#include <math.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/pwm.h"
#include "driverlib/pin_map.h"
#include <sampling.h>
#include "driverlib/timer.h"

uint32_t gSystemClock = 120000000; // [Hz] system clock frequency
#define PWM_FREQUENCY 20000 // PWM frequency = 20 kHz

/* Lab 2 Variables and Functions */
float load = 0;
float unload;
float loadc;
uint32_t CPULoad(void);

float fScale;
volatile uint32_t gTime = 8345; // time in hundredths of a second
char button;
char str[50];
int i, yval, yvalPrev, trigger;
int tSlope = 1;
int voltsPerDiv = 4;
float fVoltsPerDiv[] = {0.1, 0.2, 0.5, 1, 2};
uint16_t sample[LCD_HORIZONTAL_MAX];  // Sample on LCD
volatile int buffer[LCD_HORIZONTAL_MAX];  // Sample on LCD
const char * const gVoltageScaleStr[] = {"100 mV", "200 mV", "500 mV", " 1 V", " 2 V"};

/*
 *  ======== main ========
 */

int main(void)
{
    IntMasterDisable();

    // configure M0PWM2, at GPIO PF2, BoosterPack 1 header C1 pin 2
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);
    GPIOPinConfigure(GPIO_PF2_M0PWM2);
    GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_2,
    GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD);
    // configure the PWM0 peripheral, gen 1, outputs 2 and 3
    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
    // use system clock without division
    PWMClockSet(PWM0_BASE, PWM_SYSCLK_DIV_1);
    PWMGenConfigure(PWM0_BASE, PWM_GEN_1, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);
    PWMGenPeriodSet(PWM0_BASE, PWM_GEN_1, roundf((float)gSystemClock/PWM_FREQUENCY));
    PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2, roundf((float)gSystemClock/PWM_FREQUENCY*0.4f));
    PWMOutputState(PWM0_BASE, PWM_OUT_2_BIT, true);
    PWMGenEnable(PWM0_BASE, PWM_GEN_1);

    Crystalfontz128x128_Init(); // Initialize the LCD display driver
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP); // set screen orientation

    // hardware initialization goes here
    ButtonInit();
    ADCInitialize();
    unload = CPULoad();

    // Start BIOS
    BIOS_start();

    return (0);
}

void WaveformTask_f(UArg arg1, UArg arg2){
    IntMasterEnable();
    while(1){
        // pend on semaphore
        Semaphore_pend(Waveform_sem, BIOS_WAIT_FOREVER);

        trigger = tSlope ? RisingTrigger(): FallingTrigger();
        for (i = 0; i < LCD_HORIZONTAL_MAX - 1; i++) {
            sample[i] = gADCBuffer[ADC_BUFFER_WRAP(trigger - LCD_HORIZONTAL_MAX / 2 + i)];
        }
        Semaphore_post(Processing_sem);

    }
}


void ProcessingTask_f(UArg arg1, UArg arg2){
    while(1){
        //pend on a semaphore
        Semaphore_pend(Processing_sem, BIOS_WAIT_FOREVER);
        float fScale = (VIN_RANGE * PIXELS_PER_DIV)/((1 << ADC_BITS) * fVoltsPerDiv[voltsPerDiv]);

        for (i = 0; i < LCD_HORIZONTAL_MAX - 1; i++) {
            buffer[i] = LCD_VERTICAL_MAX / 2 - (int)roundf(fScale * ((int)sample[i] - ADC_OFFSET));
        }
        Semaphore_post(Display_sem);
        Semaphore_post(Waveform_sem);

    }
}


void DisplayTask_f(UArg arg1, UArg arg2){
    tContext sContext;
    GrContextInit(&sContext, &g_sCrystalfontz128x128);
    GrContextFontSet(&sContext, &g_sFontFixed6x8);
    tRectangle rectFullScreen = {0, 0, GrContextDpyWidthGet(&sContext)-1, GrContextDpyHeightGet(&sContext)-1};

    while(1){
        //pend on a semaphore
        Semaphore_pend(Display_sem, BIOS_WAIT_FOREVER);

        load = CPULoad();
        loadc = 1.0 - (float)load/unload;

        GrContextForegroundSet(&sContext, ClrBlack);
        GrRectFill(&sContext, &rectFullScreen);

        GrContextForegroundSet(&sContext, ClrBlue); // Blue Lines


        for(i = -3; i < 4; i++) {
            GrLineDrawH(&sContext, 0, LCD_HORIZONTAL_MAX - 1, LCD_VERTICAL_MAX/2 + i * PIXELS_PER_DIV);
            GrLineDrawV(&sContext, LCD_VERTICAL_MAX/2 + i * PIXELS_PER_DIV, 0, LCD_HORIZONTAL_MAX - 1);
        }

        GrContextForegroundSet(&sContext, ClrYellow);

        for (i = 0; i < LCD_HORIZONTAL_MAX - 1; i++){
            if (buffer[i] >= LCD_HORIZONTAL_MAX){
                yval = LCD_HORIZONTAL_MAX-1;
            } else if (buffer[i] < 0) {
                yval = 0;
            }
            else {
                yval = buffer[i];
            }
            GrLineDraw(&sContext, i, yvalPrev, i + 1, yval);
            yvalPrev = yval;
        }

        GrContextForegroundSet(&sContext, ClrWhite);

        if (tSlope){
            GrLineDraw(&sContext, 105, 10, 115, 10);
            GrLineDraw(&sContext, 115, 10, 115, 0);
            GrLineDraw(&sContext, 115, 0, 125, 0);
            GrLineDraw(&sContext, 112, 6, 115, 2);
            GrLineDraw(&sContext, 115, 2, 118, 6);
        }
        else{
            GrLineDraw(&sContext, 105, 10, 115, 10);
            GrLineDraw(&sContext, 115, 10, 115, 0);
            GrLineDraw(&sContext, 115, 0, 125, 0);
            GrLineDraw(&sContext, 112, 3, 115, 7);
            GrLineDraw(&sContext, 115, 7, 118, 3);
        }


        GrStringDraw(&sContext, "20 us", -1, 4, 0, false);
        GrStringDraw(&sContext, gVoltageScaleStr[voltsPerDiv], -1, 50, 0, false);
        snprintf(str, sizeof(str), "CPU load = %.1f%%", loadc*100);
        GrStringDraw(&sContext, str, -1, 1, 120, false);

        GrFlush(&sContext);
    }
}

void ButtonTask_f(UArg arg1, UArg arg2){
    char button;
    while (1){

        Semaphore_pend(Button_sem, BIOS_WAIT_FOREVER);

        // read hardware button state
            uint32_t gpio_buttons =
                    (~GPIOPinRead(GPIO_PORTJ_BASE, 0xff) & (GPIO_PIN_1 | GPIO_PIN_0)) | // EK-TM4C1294XL buttons in positions 0 and 1
                    ((~GPIOPinRead(GPIO_PORTH_BASE, 0xff) & GPIO_PIN_1) << 1) |         // Switch 1
                    ((~GPIOPinRead(GPIO_PORTK_BASE, 0xff) & GPIO_PIN_6) >> 3) |         // Switch 2
                    (~GPIOPinRead(GPIO_PORTD_BASE, 0xff) & GPIO_PIN_4);                 // Joystick Select

            uint32_t old_buttons = gButtons;    // save previous button state
            ButtonDebounce(gpio_buttons);       // Run the button debouncer. The result is in gButtons.
            ButtonReadJoystick();               // Convert joystick state to button presses. The result is in gButtons.
            uint32_t presses = ~old_buttons & gButtons;   // detect button presses (transitions from not pressed to pressed)
            presses |= ButtonAutoRepeat();      // autorepeat presses if a button is held long enough

            if (presses & 1) { // EK-TM4C1294XL button 1 pressed
                button = 'a';
                Mailbox_post(mailbox0, &button, BIOS_WAIT_FOREVER);
            }

            if (presses & 2) { // EK-TM4C1294XL button 2 pressed
                button = 'b';
                Mailbox_post(mailbox0, &button, BIOS_WAIT_FOREVER);
            }

            if (presses & 4) { // EK-TM4C1294XL button 4 pressed
                button = 'c';
                Mailbox_post(mailbox0, &button, BIOS_WAIT_FOREVER);
            }

            if (presses & 8){  // EK-TM4C1294XL button 8 pressed
                button = 'd';
                Mailbox_post(mailbox0, &button, BIOS_WAIT_FOREVER);
            }
    }
}

void UserInputTask_f(UArg arg1, UArg arg2){
    while (1){
        Mailbox_pend(mailbox0, &button, BIOS_WAIT_FOREVER);
            switch(button){
                case 'a':
                    voltsPerDiv = (voltsPerDiv+1) > 4 ? 4 : (voltsPerDiv + 1);
                    break;
                case 'b':
                    voltsPerDiv = (voltsPerDiv-1) <= 0 ? 0 : (voltsPerDiv-1);
                    break;
                case 'c':
                    tSlope = !tSlope;
                    break;
            }
        }
}

void Clock0Task(UArg arg1, UArg arg2)
{
    Semaphore_post(Button_sem);
}

uint32_t CPULoad(void){
    uint32_t i = 0;
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER3_BASE, TIMER_A);
    while (!(TimerIntStatus(TIMER3_BASE, false) & TIMER_TIMA_TIMEOUT)) {
        i++;
    }
    return i;
}
